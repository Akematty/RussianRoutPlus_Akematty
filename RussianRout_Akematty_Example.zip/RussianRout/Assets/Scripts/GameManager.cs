﻿using UnityEngine;

/*列挙型:ゲームステート*/
public enum GameState : byte
{
    READY = 0,  /*ゲーム開始前:諸データの格納*/
    PLAYING,    /*ゲーム中*/
    GAME_OVER   /*ゲーム終了*/
};

public class GameManager : MonoBehaviour {
    /*ゲームステート*/
    private static GameState gameState;
    /*プロパティ*/
    public static GameState GameStateProp
    {
        get
        {
            return gameState;
        }

        set
        {
            gameState = value;
        }
    }

}
