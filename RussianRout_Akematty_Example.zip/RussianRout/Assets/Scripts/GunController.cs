﻿#undef ONE_BULLET_MODE              //プリプロセッサ:弾が１この時
#define NOT_ONE_BULLET_MODE         //プリプロセッサ:弾が２個以上の時
using UnityEngine;
using System.Collections.Generic;

public class GunController : MonoBehaviour {

    [SerializeField]
    private int shooterNum;         /*撃ち手の数*/
    private int shooterID;          /*撃ち手のID番号*/

    private int shotBulletBoxID;    /*次に撃つ弾倉番号*/

#if ONE_BULLET_MODE
    [SerializeField]
    private int bulletBox;          /*装填数*/
#endif

#if ONE_BULLET_MODE
    [SerializeField]
    private int bulletPosition;     /*銃弾が入っている番号*/
#endif

#if NOT_ONE_BULLET_MODE
    /*弾倉*/
    [SerializeField]
    private bool [ ] isBullet;      /*trueなら弾が入っていると考える*/

    private int bulletNum;

    #endif

    private List<Player> playerList;/*プレイヤーのリスト*/

    /*Start関数の前に行う関数*/
    private void Awake( )
    {
        GameManager.GameStateProp = GameState.READY;/*ゲームステートをREADYに初期化*/

        /*各値の初期化*/
        this.shooterNum         = 6;/*撃ち手の数*/
        this.shooterID          = 0;/*撃ち手のID番号*/
        this.shotBulletBoxID    = 0;/*次に撃つ弾倉番号*/

#if ONE_BULLET_MODE
        this.bulletBox          = 6;/*装填数*/
        this.bulletPosition     = 4;/*銃弾が入っている番号*/

        /*プレイヤーリストを実体化*/
        this.playerList         = new List<Player>();
        /*エラー処理*/
        /*弾が入っている番号が,装弾数より大きいと存在しない弾倉に弾をつめることになる*/
        if(this.bulletPosition<0 
            || this.bulletBox <= this.bulletPosition)
        {
            this.bulletPosition = this.bulletPosition - 1;/*一番最後の弾倉番号に弾をこめる*/
        }
#endif

#if NOT_ONE_BULLET_MODE
        /*残弾数を初期化*/
        this.bulletNum = 0;

        for(int i = 0; i < isBullet.Length; i++)
        {
            //print(i + ">" + isBullet [i]);    /*デバッグ*/
            /*弾が入っていたら増やす*/
            if (this.isBullet [i])
            {
                this.bulletNum++;
            }
        }
#endif

        /*プレイヤーリストを実体化*/
        this.playerList = new List<Player>( );
        /*プレイヤー情報をリストに追加する*/
        for (int i = 0; i < this.shooterNum; i++)
        {
            Player player = new Player();   /*Playerクラスを実体化*/
            playerList.Add(player);         /*リストに追加*/
            playerList[i].IDProp = i;       /*ID番号を追加*/
        }

        GameManager.GameStateProp = GameState.PLAYING;/*ゲームステートをPLAYINGにする*/
    }

    /*情報表示_CONSOLE上にしか流れない*/
    /*                      プレイヤーID,撃つ弾倉のID,どのボタンが押されたか*/
    private void PrintInfo(int player,int box, string msg)
    {
        /*例：Player0:BulletNumber0=>SHOT*/
        print("Player" + player + ":" + "BullerNumber" + box +"=>"+msg);
    }

    /*Shotボタン押したとき,呼び出される関数*/
    public void Shot()
    {
#if ONE_BULLET_MODE
        /*撃つ弾倉番号==玉が入った弾倉番号*/
        if(this.shotBulletBoxID == this.bulletPosition)
        {
            GameManager.GameStateProp           = GameState.GAME_OVER;          /*ゲームオーバー*/
            print("DIE");                                                       /*ゲームオーバーしたらDIE連絡*/
        }
#endif
        /*情報表示*/
        PrintInfo(this.shooterID, this.shotBulletBoxID, "SHOT");
#if NOT_ONE_BULLET_MODE
        if (this.isBullet [this.shotBulletBoxID])
        {
            GameManager.GameStateProp = GameState.GAME_OVER;                /*ゲームステートをGAME_OVERに*/
            print("DIE");                                                   /*ゲームオーバーしたらDIE連絡*/
        }
#endif

        else
        {
            /*弾倉回転*/
            this.shotBulletBoxID++;                         /*番号を１増やす*/
#if ONE_BULLET_MODE
        this.shotBulletBoxID %= this.bulletBox;         /*番号を全装填数で割った余りを出力*/
#endif
#if NOT_ONE_BULLET_MODE
            this.shotBulletBoxID %= this.isBullet.Length;   /*番号を全装填数で割った余りを出力*/
#endif

            /*打ち手チェンジ*/
            this.shooterID++;                       /*番号を１増やす*/
            this.shooterID %= this.shooterNum;       /*番号を人数で割った余りを出力*/
        }
    }

    /*PASSボタンを御した時,呼び出される関数*/
    public void Pass()
    {
        /*情報表示*/
        PrintInfo(this.shooterID, this.shotBulletBoxID,"PASS");

        /*まだそのプレイヤーがパスしてない*/
        if (this.playerList[this.shooterID].IsPass == false)
        {
            this.playerList[this.shooterID].IsPass = true;  /*パスした*/

            /*弾倉回転*/
            this.shotBulletBoxID++;                         /*番号を１増やす*/
#if ONE_BULLET_MODE
            this.shotBulletBoxID %= this.bulletBox;         /*番号を全装填数で割った余りを出力*/
#endif
#if NOT_ONE_BULLET_MODE
            this.shotBulletBoxID %= this.isBullet.Length;   /*番号を全装填数で割った余りを出力*/
#endif
            /*打ち手チェンジ*/
            this.shooterID++;                               /*番号を１増やす*/
            this.shooterID %= this.shooterNum;              /*番号を人数で割った余りを出力*/
        }
    }

#region プロパティ
    /*撃ち手番号*/
    public int ShooterIDProp
    {
        get
        {
            return this.shooterID;
        }
        set
        {

        }
    }
    /*次に撃つ弾倉番号*/
    public int ShotBulletBoxIDProp
    {
        get
        {
            return this.shotBulletBoxID;
        }
        set
        {

        }
    }
    /*残弾数*/
    public int BulletNumProp
    {
        get
        {
            return this.bulletNum;
        }
        set
        {

        }
    }

#endregion
}