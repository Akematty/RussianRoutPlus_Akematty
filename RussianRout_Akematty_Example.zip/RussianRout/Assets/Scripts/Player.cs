﻿using System;

public class Player {

    /*プレイヤー情報*/
    private int id;     /*プレイヤーID*/
    private bool isPass;/*パスしたかどうか*/

    /*コンストラクタ*/
    public Player()
    {
        this.isPass = false;
    }

    #region Property

    /*ID*/
    public int IDProp
    {
        get
        {
            return this.id;
        }
        set
        {
            this.id = value;
        }
    }
    /*パスしたかどうか*/
    public bool IsPass
    {
        get
        {
            return this.isPass;
        }
        set
        {
            this.isPass = value;
        }
    }

    #endregion
}
