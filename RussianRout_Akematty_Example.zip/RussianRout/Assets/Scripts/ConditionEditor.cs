﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class ConditionEditor : MonoBehaviour {

    /*GunControllerクラス*/
    private GunController gunController;
    /*GunControllerクラスをアタッチしているオブジェクト*/
    [SerializeField]
    private GameObject managerObject;

    private void Safe ( int leftNum )
    {
        GetComponent<Text>( ).text = "BULLET =>" + leftNum.ToString( );/*残弾数をstringにキャストして表示*/
    }

    private void GameOver(string player )
    {
        GetComponent<Text>( ).text = player +" IS DEAD...";
    }

    private void Start ( )
    {
        this.gunController = this.managerObject.GetComponent<GunController>( );/*コンポーネント取得*/
                
    }

    private void Update ( )
    {
        /*ゲームステートがGAME_OVERかどうか*/
        if (GameManager.GameStateProp == GameState.GAME_OVER)
        {
            GameOver("PLAYER " + this.gunController.ShooterIDProp.ToString( ));/*死亡したプレイヤーの番号がずれる場合がある,要修正<=修正完了(2016/07/21)*/
        }
        else
        {
            Safe(this.gunController.BulletNumProp);/*表示*/
        }
    }
    
}
