﻿using UnityEngine;
using UnityEngine.UI;

public class ButtonController : MonoBehaviour {

	void Update ()
    {
        /*ゲームステートの値を取得<=GameManagerクラスから持ってくる*/
        GameState state = GameManager.GameStateProp;

        #region 分岐
        switch (state)
        {
            /*READY=>ボタン無効*/
            case GameState.READY:
                GetComponent<Button>().enabled = false;
                break;
            /*PLAYING=>ボタン有効*/
            case GameState.PLAYING:
                GetComponent<Button>().enabled = true;
                break;
            /*GAME_OVER=>ボタン無効*/
            case GameState.GAME_OVER:
                GetComponent<Button>().enabled = false;
                break;
            /*何もしない*/
            default:
                break;
        }
        #endregion
    }
}
