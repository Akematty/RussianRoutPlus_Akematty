﻿#undef ORIGINAL

using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class TurnPlayerEditor : MonoBehaviour {

    /*GunControllerクラス*/
    private GunController gunController;
    /*GunControllerクラスをアタッチしているオブジェクト*/
    [SerializeField]
    private GameObject managerObject;

    private void Start ( )
    {
        this.gunController = this.managerObject.GetComponent<GunController>( );/*コンポーネント取得*/
#if ORIGINAL
        DisplayPlayerInfo( );
#endif

        int playerID = this.gunController.ShooterIDProp;            /*撃ち手のID番号*/

        PlayerWrite("PLAYER:" + playerID.ToString( ));              /*引数にはプレイヤーID(撃ち手のID番号)をstringにキャストして追加*/

    }

#if ORIGINAL
    /*現在銃を握っているプレイヤー情報を表示する*/
    /*SHOT,PASSボタンが押された時に処理される || 引数にはどのボタンが押されたか入る(0=>SHOT,1=>PASS)*/
    public void DisplayPlayerInfo ( )
    {
        /*表示する情報の取得*/
        int playerID = this.gunController.ShooterIDProp;         /*撃ち手のID番号*/
        int boxNumber = this.gunController.ShotBulletBoxIDProp;   /*次に撃つ弾倉番号*/

        /*ゲームステートがGAME_OVERでなければ表示処理を行う*/
        if (GameManager.GameStateProp != GameState.GAME_OVER)
        {
            /*表示*/
            GetComponent<Text>( ).text = "TURN=>PLAYER " + playerID.ToString( ) + " BB=>" + boxNumber.ToString( );
        }
    }
#endif

    public void PlayerWrite (string player )
    {
        GetComponent<Text>( ).text = player;
    }

    private void Update ( )
    {
        /*ゲームステートがPLAYINGの場合のみ更新*/
        if (GameManager.GameStateProp == GameState.PLAYING)
        {

            int playerID = this.gunController.ShooterIDProp;            /*撃ち手のID番号*/

            PlayerWrite("PLAYER:" + playerID.ToString( ));              /*引数にはプレイヤーID(撃ち手のID番号)をstringにキャストして追加*/
        }
    }
}
